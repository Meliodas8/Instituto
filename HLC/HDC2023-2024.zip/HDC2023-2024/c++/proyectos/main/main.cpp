#include <iostream>

int main() {
    std::cout << "Hola mundo\n";
    std::cin.get();
    system("pause");
    return 0;
}